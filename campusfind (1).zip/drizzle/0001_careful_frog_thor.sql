CREATE TABLE `items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerId` int NOT NULL,
	`type` enum('LOST','FOUND') NOT NULL,
	`name` varchar(160) NOT NULL,
	`category` varchar(80) NOT NULL,
	`itemDate` timestamp NOT NULL,
	`location` varchar(160) NOT NULL,
	`description` text NOT NULL,
	`photoUrl` varchar(600),
	`contact` varchar(240) NOT NULL,
	`status` enum('OPEN','RETURNED') NOT NULL DEFAULT 'OPEN',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `items_id` PRIMARY KEY(`id`)
);
