import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertItem, InsertUser, items, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try { _db = drizzle(process.env.DATABASE_URL); }
    catch (error) { console.warn("[Database] Failed to connect:", error); _db = null; }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) { values[field] = user[field] ?? null; updateSet[field] = user[field] ?? null; }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role) { values.role = user.role; updateSet.role = user.role; }
  else if (user.openId === ENV.ownerOpenId) { values.role = "admin"; updateSet.role = "admin"; }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listItems(filters: { q?: string; type?: "ALL" | "LOST" | "FOUND"; category?: string; status?: "ALL" | "OPEN" | "RETURNED"; location?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters.type && filters.type !== "ALL") conditions.push(eq(items.type, filters.type));
  if (filters.status && filters.status !== "ALL") conditions.push(eq(items.status, filters.status));
  if (filters.category && filters.category !== "ALL") conditions.push(eq(items.category, filters.category));
  if (filters.location) conditions.push(like(items.location, `%${filters.location}%`));
  if (filters.q) {
    const term = `%${filters.q}%`;
    conditions.push(or(like(items.name, term), like(items.description, term), like(items.location, term)));
  }
  return db.select().from(items).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(items.createdAt));
}

export async function getItemById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(items).where(eq(items.id, id)).limit(1);
  return rows[0];
}

export async function createItem(item: InsertItem) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(items).values(item);
  return getItemById(Number(result[0].insertId));
}

export async function updateItem(id: number, patch: Partial<InsertItem>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(items).set(patch).where(eq(items.id, id));
  return getItemById(id);
}

export async function deleteItem(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(items).where(eq(items.id, id));
}

export async function getItemStats() {
  const db = await getDb();
  if (!db) return { total: 0, open: 0, returned: 0, lost: 0, found: 0 };
  const rows = await db.select({
    total: sql<number>`count(*)`,
    open: sql<number>`sum(case when ${items.status} = 'OPEN' then 1 else 0 end)`,
    returned: sql<number>`sum(case when ${items.status} = 'RETURNED' then 1 else 0 end)`,
    lost: sql<number>`sum(case when ${items.type} = 'LOST' then 1 else 0 end)`,
    found: sql<number>`sum(case when ${items.type} = 'FOUND' then 1 else 0 end)`,
  }).from(items);
  const row = rows[0];
  return { total: Number(row?.total ?? 0), open: Number(row?.open ?? 0), returned: Number(row?.returned ?? 0), lost: Number(row?.lost ?? 0), found: Number(row?.found ?? 0) };
}
