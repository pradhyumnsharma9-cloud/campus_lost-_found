import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getItemById, getItemStats, createItem, deleteItem, listItems, updateItem } from "./db";
import { storagePut } from "./storage";
import { publicProcedure, protectedProcedure, adminProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";

const itemInput = z.object({
  type: z.enum(["LOST", "FOUND"]),
  name: z.string().trim().min(2).max(160),
  category: z.string().trim().min(2).max(80),
  itemDate: z.coerce.date(),
  location: z.string().trim().min(2).max(160),
  description: z.string().trim().min(10).max(2000),
  photoUrl: z.union([z.string().url().max(600), z.string().regex(/^\/manus-storage\/[A-Za-z0-9._/-]+$/).max(600), z.literal("")]).optional(),
  contact: z.string().trim().min(3).max(240),
});

const filters = z.object({
  q: z.string().optional(),
  type: z.enum(["ALL", "LOST", "FOUND"]).default("ALL"),
  category: z.string().optional(),
  status: z.enum(["ALL", "OPEN", "RETURNED"]).default("ALL"),
  location: z.string().optional(),
});

function assertOwner(item: { ownerId: number }, userId: number) {
  if (item.ownerId !== userId) throw new TRPCError({ code: "FORBIDDEN", message: "You can only manage your own reports." });
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  items: router({
    list: publicProcedure.input(filters).query(({ input }) => listItems(input)),
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(({ input }) => getItemById(input.id)),
    stats: publicProcedure.query(() => getItemStats()),
    create: protectedProcedure.input(itemInput).mutation(({ ctx, input }) => createItem({ ...input, photoUrl: input.photoUrl || null, ownerId: ctx.user.id, status: "OPEN" })),
    update: protectedProcedure.input(z.object({ id: z.number().int().positive(), data: itemInput })).mutation(async ({ ctx, input }) => {
      const item = await getItemById(input.id);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
      assertOwner(item, ctx.user.id);
      return updateItem(input.id, { ...input.data, photoUrl: input.data.photoUrl || null });
    }),
    remove: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const item = await getItemById(input.id);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
      assertOwner(item, ctx.user.id);
      await deleteItem(input.id);
      return { success: true };
    }),
    markReturned: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const item = await getItemById(input.id);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Report not found." });
      assertOwner(item, ctx.user.id);
      return updateItem(input.id, { status: "RETURNED" });
    }),
  }),
  uploads: router({
    itemPhoto: protectedProcedure.input(z.object({
      fileName: z.string().trim().min(1).max(180),
      contentType: z.enum(["image/jpeg", "image/png", "image/webp"]),
      data: z.string().min(1),
    })).mutation(async ({ ctx, input }) => {
      const raw = input.data.replace(/^data:[^;]+;base64,/, "");
      const bytes = Buffer.from(raw, "base64");
      if (bytes.length === 0 || bytes.length > 5 * 1024 * 1024) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Photo must be smaller than 5 MB." });
      }
      const safeName = input.fileName.replace(/[^a-zA-Z0-9._-]/g, "-");
      return storagePut(`campus-lost-found/${ctx.user.id}/${safeName}`, bytes, input.contentType);
    }),
  }),
  admin: router({
    list: adminProcedure.input(filters).query(({ input }) => listItems(input)),
    stats: adminProcedure.query(() => getItemStats()),
    update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: itemInput })).mutation(async ({ input }) => updateItem(input.id, { ...input.data, photoUrl: input.data.photoUrl || null })),
    updateStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), status: z.enum(["OPEN", "RETURNED"]) })).mutation(async ({ input }) => updateItem(input.id, { status: input.status })),
    remove: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => { await deleteItem(input.id); return { success: true }; }),
  }),
});

export type AppRouter = typeof appRouter;
